const $ = s => document.querySelector(s);
const fields = [...document.querySelectorAll("[data-field]")];
let mode = "pharmacy";
let items = [];
const defaults = {
 pharmacy:{orgName:"SAMPLE MEDICAL STORE",orgAddress:"Demo address, City, State",orgContact:"Phone: 00000 00000",orgReg:"GSTIN: DEMO ONLY",docNo:"DEMO-INV-001",personName:"Sample Customer",personAddress:"Demo address",mobile:"00000 00000",provider:"Billing Counter",note:"SAMPLE ONLY — not valid for payment or reimbursement.",discount:0,signatory:"Demo Authorised Person"},
 hospital:{orgName:"SAMPLE CARE HOSPITAL",orgAddress:"Demo hospital address, City, State",orgContact:"Phone: 00000 00000 | demo@example.com",orgReg:"Registration: DEMO ONLY",docNo:"DEMO-OPD-001",personName:"Sample Patient",personAddress:"Demo address",mobile:"00000 00000",provider:"Orthopaedics / Demo Doctor",note:"SAMPLE ONLY — not a medical record or proof of payment.",discount:0,signatory:"Demo Authorised Person"}
};
const sampleItems = {
 pharmacy:[{name:"Demo tablet (not a real prescription)",qty:2,rate:100,gst:5},{name:"Demo capsule",qty:1,rate:80,gst:5}],
 hospital:[{name:"Demo consultation service",qty:1,rate:500,gst:0},{name:"Demo imaging service",qty:1,rate:400,gst:0}]
};
function setDefaults(){
 const d=defaults[mode];
 fields.forEach(f=>{f.value=d[f.dataset.field] ?? ""});
 items=sampleItems[mode].map(x=>({...x}));
 renderEditor();render();
}
function renderEditor(){
 $("#itemEditor").innerHTML=items.map((it,i)=>`<div class="item-row">
 <input aria-label="Description" data-i="${i}" data-k="name" value="${escapeHtml(it.name)}" placeholder="Description">
 <input aria-label="Qty" type="number" min="0" step="1" data-i="${i}" data-k="qty" value="${it.qty}">
 <input aria-label="Rate" type="number" min="0" step=".01" data-i="${i}" data-k="rate" value="${it.rate}">
 <button type="button" data-remove="${i}" title="Remove">×</button>
 </div>`).join("");
 $("#itemEditor").querySelectorAll("input").forEach(inp=>inp.addEventListener("input",e=>{
   const i=+e.target.dataset.i,k=e.target.dataset.k;items[i][k]=k==="name"?e.target.value:Number(e.target.value)||0;render();
 }));
 $("#itemEditor").querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{items.splice(+b.dataset.remove,1);renderEditor();render()}));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function val(k){return $(`[data-field="${k}"]`).value}
function money(n){return "₹"+Number(n||0).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}
function render(){
 const get=k=>val(k);
 const map={orgName:"pOrgName",orgAddress:"pOrgAddress",orgContact:"pOrgContact",orgReg:"pOrgReg",docNo:"pDocNo",personName:"pPersonName",personAddress:"pPersonAddress",mobile:"pMobile",provider:"pProvider",note:"pNote",signatory:"pSignatory"};
 Object.entries(map).forEach(([k,id])=>$("#"+id).textContent=get(k));
 $("#pDocTitle").textContent=mode==="pharmacy"?"GST INVOICE • CASH":"OUT PATIENT BILL CUM RECEIPT";
 const dt=get("date");$("#pDate").textContent=dt?new Date(dt+"T00:00:00").toLocaleDateString("en-IN"):"";
 $("#itemsHeading").textContent=mode==="pharmacy"?"दवाइयाँ / आइटम":"सेवाएँ / आइटम";
 $("#tableHead").innerHTML=mode==="pharmacy"?'<tr><th>Sr.</th><th>Particulars</th><th>Qty</th><th>Rate</th><th>GST</th><th>Amount</th></tr>':'<tr><th>Sr.</th><th>Particulars</th><th>Qty</th><th>Rate</th><th>Amount</th></tr>';
 let subtotal=0,tax=0;
 $("#previewRows").innerHTML=items.map((it,i)=>{
  const base=(Number(it.qty)||0)*(Number(it.rate)||0),gst=mode==="pharmacy"?base*.05:0;subtotal+=base;tax+=gst;
  return mode==="pharmacy"?`<tr><td>${i+1}</td><td>${escapeHtml(it.name)}</td><td>${it.qty}</td><td>${money(it.rate)}</td><td>${money(gst)}</td><td>${money(base+gst)}</td></tr>`:`<tr><td>${i+1}</td><td>${escapeHtml(it.name)}</td><td>${it.qty}</td><td>${money(it.rate)}</td><td>${money(base)}</td></tr>`;
 }).join("");
 const discount=Math.max(0,Number(get("discount"))||0),total=Math.max(0,subtotal+tax-discount);
 $("#amounts").innerHTML=`<div><span>Subtotal</span><b>${money(subtotal)}</b></div>${mode==="pharmacy"?`<div><span>Demo GST (5%)</span><b>${money(tax)}</b></div>`:""}<div><span>Discount</span><b>${money(discount)}</b></div><div class="grand"><span>Demo Total</span><b>${money(total)}</b></div>`;
 $("#amountWords").textContent="Amount in words: "+(total.toFixed(2))+" rupees only (demo calculation)";
}
fields.forEach(f=>f.addEventListener("input",render));
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{
 mode=b.dataset.mode;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));setDefaults();
}));
$("#addItemBtn").addEventListener("click",()=>{items.push({name:"New demo item",qty:1,rate:0,gst:0});renderEditor();render()});
$("#printBtn").addEventListener("click",()=>window.print());
$("#resetBtn").addEventListener("click",setDefaults);
setDefaults();
