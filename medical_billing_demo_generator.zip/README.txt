MEDICAL BILLING DEMO GENERATOR

Files:
- index.html
- styles.css
- app.js

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, or Firefox.
3. Select Pharmacy Invoice or Hospital Receipt.
4. Edit the fields and line items.
5. Click "PDF डाउनलोड / Print" and choose "Save as PDF".

This is a SAMPLE/DEMO template only. It intentionally includes visible SAMPLE / NOT VALID markings.
It is not an official pharmacy invoice, hospital receipt, proof of payment, medical record, or insurance-claim document.
For a genuine duplicate/reprint, request it from the issuing pharmacy or hospital.
